@echo off
title TCM-Link - Trang IMC
cd /d "%~dp0"

echo ====================================================================
echo    TCM-Link - Trang IMC Healthcare Referral System
echo ====================================================================
echo.

:: Check if port 3000 is already running
netstat -ano | findstr ":3000 " | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    echo [INFO] Server is already running on port 3000.
    echo Opening browser to http://localhost:3000 ...
    start "" "http://localhost:3000"
    timeout /t 2 >nul
    exit /b 0
)

echo Starting TCM-Link server...
echo Opening http://localhost:3000 in your browser...
echo.

start "" cmd /c "timeout /t 3 >nul & start http://localhost:3000"

set NODE_ENV=production
if exist "%~dp0runtime\node.exe" (
    if exist "%~dp0dist\server.cjs" (
        "%~dp0runtime\node.exe" "%~dp0dist\server.cjs"
        exit /b 0
    )
)
if exist "%~dp0dist\server.cjs" (
    node "%~dp0dist\server.cjs"
    exit /b 0
)

npm run dev
pause