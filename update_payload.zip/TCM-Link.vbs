Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = currentDir

' Check if port 3000 is listening
Set oExec = WshShell.Exec("netstat -ano")
running = False
Do While Not oExec.StdOut.AtEndOfStream
    line = oExec.StdOut.ReadLine()
    If InStr(line, ":3000 ") > 0 And InStr(line, "LISTENING") > 0 Then
        running = True
        Exit Do
    End If
Loop

If Not running Then
    ' Start server silently in hidden window (0 = hidden)
    If fso.FileExists(currentDir & "\runtime\node.exe") And fso.FileExists(currentDir & "\dist\server.cjs") Then
        WshShell.Run """" & currentDir & "\runtime\node.exe"" """ & currentDir & "\dist\server.cjs""", 0, False
    ElseIf fso.FileExists(currentDir & "\dist\server.cjs") Then
        WshShell.Run "cmd /c node dist\server.cjs", 0, False
    Else
        WshShell.Run "cmd /c npm run dev", 0, False
    End If
    WScript.Sleep 2500
End If

' Locate Chrome or Edge for standalone desktop app window mode (--app)
browser = ""
If fso.FileExists("C:\Program Files\Google\Chrome\Application\chrome.exe") Then
    browser = "C:\Program Files\Google\Chrome\Application\chrome.exe"
ElseIf fso.FileExists("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe") Then
    browser = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
ElseIf fso.FileExists("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe") Then
    browser = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
ElseIf fso.FileExists("C:\Program Files\Microsoft\Edge\Application\msedge.exe") Then
    browser = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
End If

If browser <> "" Then
    WshShell.Run """" & browser & """ --app=http://localhost:3000", 1, False
Else
    WshShell.Run "http://localhost:3000", 1, False
End If
