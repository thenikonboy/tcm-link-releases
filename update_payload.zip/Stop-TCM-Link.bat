@echo off
chcp 65001 > nul
cls
echo ================================================================
echo    ปิดการทำงานของโปรแกรม TCM-Link
echo ================================================================
echo กำลังหยุดการทำงานของเซิร์ฟเวอร์...

for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3000 " ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

echo [OK] ปิดโปรแกรมและคืนหน่วยความจำเรียบร้อยแล้ว
timeout /t 2 >nul
exit /b 0
